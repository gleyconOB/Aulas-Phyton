nomeCar= input("Digite o nome do carro: ")
placaCar = input("Digite o número da placa: ")
modeloCar = input("Qual o modelo do carro: ")
corCaro = input("Qual a cor do carro: ")
print("Seu carro é: ", nomeCar)
print("A Placa do seu carro: ",placaCar)
print("O Modelo do seu carro: ",modeloCar)
print("Cor do carro: ", corCaro)

