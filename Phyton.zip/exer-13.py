numero=float(input("Digite um número:"))

if(numero % 2 == 0):
    print("O número digitado é par")
else:
    print("O número digitado é impar")    