alturaR = float(input("Digite a altura de um retangulo: "))
baseR = float(input("Digite a base de um retangulo: "))

retangulo = alturaR * baseR

print("A area de do retangulo é: ", retangulo)