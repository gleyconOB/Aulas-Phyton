letra = input("Digite 'F' para feminino ou 'M' para masculino: ")

if(letra.upper() == 'F'):
    print("Feminino")
elif(letra.upper() == 'M'):
    print("Masculino")
else:
    print("Sexo inválido")
