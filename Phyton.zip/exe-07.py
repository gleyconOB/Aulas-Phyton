baseR = float(input("Digite a base de um triangulo: "))
alturaR = float(input("Digite a altura de um retangulo: "))

triangulo = (baseR * alturaR) / 2

print("A area de do retangulo é: ", triangulo)