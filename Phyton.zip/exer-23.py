quantFR=int(input("Quantidade de frangos na granja: "))

chipID= 4
anelAli=3.5

gastoGr = quantFR* ((chipID * 1) + (anelAli * 2))

print("Quantidade gasta na granja: R$", gastoGr)