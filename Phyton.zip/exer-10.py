numero = float(input("Digite um número: "))
if(numero > 10):
    print("O número", numero, "É MAIOR Q 10!!!")
elif(numero < 10):
    print("O número", numero, "É MENOR Q 10!!!")
elif(numero == 10):
    print("O númeo", numero, "É IGUAL A 10!!!")        